package com.example;

import com.example.config.AppConfig;
import com.example.entity.Employee;
import com.example.service.EmployeeService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        EmployeeService employeeService = context.getBean(EmployeeService.class);

        // Create a new employee
        Employee employee = new Employee();
        employee.setEmpname("Alice Johnson");
        employee.setJob("Designer");

        // Save employee
        employeeService.save(employee);

        // Fetch all employees
        for (Employee emp : employeeService.findAll()) {
            System.out.println(emp.getEmpname() + " - " + emp.getJob());
        }

        context.close();
    }
}
