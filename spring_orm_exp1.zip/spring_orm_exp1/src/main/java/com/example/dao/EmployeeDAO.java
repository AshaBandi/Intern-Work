package com.example.dao;

import com.example.entity.Employee;
import java.util.List;

public interface EmployeeDAO {
    void save(Employee employee);
    List<Employee> findAll();
}
