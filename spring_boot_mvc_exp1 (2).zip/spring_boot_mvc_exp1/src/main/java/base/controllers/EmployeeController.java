package base.controllers;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import base.models.Employee;
import base.services.EmpService;

@Controller
public class EmployeeController {

	private final EmpService empService;
	private static final Logger logger = LoggerFactory.getLogger(EmployeeController.class);

	@Autowired
	public EmployeeController(EmpService empService) {
		this.empService = empService;
	}

	@GetMapping(value = "/emplist")
	public String getAllEmployees(Model model) {
		logger.info("Handling /emplist request");
		List<Employee> empList = empService.findAll();
		model.addAttribute("elist", empList);
		return "emplist";
	}

	@GetMapping("/new")
	public String showAddEmployeeForm(Model model) {
		model.addAttribute("employee", new Employee());
		return "newemp";
	}

	@PostMapping("/add")
	public String addEmployee(@ModelAttribute Employee employee, BindingResult result) {
		if (result.hasErrors()) {
			return "newemp";
		}
		empService.save(employee);
		return "redirect:/emplist";
	}

	@GetMapping("/edit/{id}")
	public String showEditEmployeeForm(@PathVariable("id") Integer id, Model model) {
		Optional<Employee> employee = empService.findById(id);
		if (employee.isPresent()) {
			logger.info("Found employee with id: " + id);
			model.addAttribute("employee", employee.get());
			return "editemp";
		} else {
			logger.warn("No employee found with id: " + id);
			return "redirect:/emplist";
		}
	}

	@PostMapping("/update/{id}")
	public String updateEmployee(@PathVariable("id") Integer id, @ModelAttribute Employee employee,
			BindingResult result) {
		if (result.hasErrors()) {
			return "editemp";
		}
		employee.setEmpNo(id);
		empService.save(employee);
		return "redirect:/emplist";
	}

	@GetMapping("/delete/{id}")
	public String deleteEmployee(@PathVariable("id") Integer id) {
		empService.deleteById(id);
		return "redirect:/emplist";
	}
}
