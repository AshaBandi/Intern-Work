package base.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import base.models.Employee;

public interface EmpRepository extends JpaRepository<Employee, Integer> {
}
